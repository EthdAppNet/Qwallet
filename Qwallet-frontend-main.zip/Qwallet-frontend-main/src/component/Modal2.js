import React from "react";
import ReactDOM from "react-dom";
import {useEffect, useState } from "react";
import { CopyToClipboard } from 'react-copy-to-clipboard';
import { FaCopy , FaWindowClose} from 'react-icons/fa';
import { FcApproval} from "react-icons/fc";
import classes from ".././component/layout/TxForm.module.css";

function Modal2(props) {

const [copied, setCopied] = useState(false);
const [cdata, setData] = useState("");

	function cancelHandler() {
	//	props.onCancel();
	}
	function copyHandler() {
			setCopied(true);
	}

return (
<div className="modal2">
<div>	
<div className="rowC">
<p className={classes.h}> Transaction Sent	<FcApproval size='25'/></p>
			</div>

		</div>	
		</div>
	);
}
export default Modal2;
