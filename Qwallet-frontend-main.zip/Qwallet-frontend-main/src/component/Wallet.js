import React from "react";
import ReactDOM from "react-dom";
import { useState } from "react";
import Modal from "./Modal";
import Backdrop from "./Backdrop";


function Wallet(props) {
  const [ModelisOpen, setModelIsOpen] = useState(false);

  function closeModalHandler() {
    setModelIsOpen(false);
  }
  function generateHandler() {
    setModelIsOpen(true);
  }

  return (
    <div className="card">
      <h2> {props.text} </h2>
      <div className="actions">
        <button className="btn" onClick={generateHandler}>
          Generate
        </button>
       
      </div>
      {ModelisOpen && (
        <Modal onCoin={props.text} onCancel={closeModalHandler} />
      )}
      {ModelisOpen && <Backdrop onCancel={closeModalHandler} />}
    </div>
  );
}

export default Wallet;
