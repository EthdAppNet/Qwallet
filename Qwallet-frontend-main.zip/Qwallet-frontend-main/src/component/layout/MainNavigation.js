import React from "react";
import ReactDOM from "react-dom";
import { Link } from "react-router-dom";
import classes from "./MainNavigation.module.css";
import { CopyToClipboard } from 'react-copy-to-clipboard';

function MainNavigation() {
	return (
		<header className={classes.header}>
			<img className={classes.img} src="qm.png" />

			<nav>
				<ul>
					<li>
						<Link to="/"> Wallet </Link>
					</li>
					<li>
						<Link to="/favorites"> Addresses </Link>
					</li>
					<li>
						<Link to="/All"> History </Link>
					</li>

				</ul>
			</nav>
		</header>
	);
}
export default MainNavigation;
