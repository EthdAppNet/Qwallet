import React from "react";
import {useRef} from "react";
import { useState } from 'react';
import ReactDOM from "react-dom";
import classes from ".././component/layout/TxForm.module.css";
import classes2 from ".././component/layout/Select.module.css";
import { FcOk, FcHighPriority } from "react-icons/fc";
import { FaEye} from "react-icons/fa";

function Search() {
	const addressInputRef= useRef();
	let privkeydisplay;
  const [privKey, getPrivKey] = useState('');
  const [bal, getBal] = useState('');
  const [status, getStatus] =useState(false);
  const [reveal, getReveal] =useState(false);
  const [clickreveal, getclickReveal] =useState(false);

function revealHandler() {
getReveal(true);
}
function unrevealHandler() {
getReveal(false);
getclickReveal(false);
}
function clickrevealHandler() {
getclickReveal(true);
}

	function submitHandler(event) {
		 event.preventDefault();

		 const enteredAddress = addressInputRef.current.value; 


	const data = {enteredAddress};
	const options = {
	method: 'POST',
	headers : {
		'Content-Type' : 'application/json'
	},

	body : JSON.stringify(data)
	};

	fetch("http://localhost:4000/api", options).then((res) => {
			return res.json();
		}).then((data) => {
			getPrivKey(data.privkey);
			getBal(data.balance);
			console.log (data.privkey);
			console.log (bal);
			getStatus(true);
			if (typeof(privKey) == 'undefined')
{			unrevealHandler();
} else {
	revealHandler();
}

		});
	}

	return (

		<div className={classes.card2} >
			<form className={classes.form} onSubmit={submitHandler}>
				<div className={classes.control}>

					<label htmlFor='address'> Search Address:</label>
    				<input type="text" required id='address' placeholder="0xb794f5ea0ba39494ce839613fffba74279579268" ref={addressInputRef}/>

					<div className={classes2.selectdiv}>
						<label>
							<select>
								<option defaultValue= 'Coin'> Select Coin </option>
								<option value='Ethereum'> Ethereum</option>
								<option value='Bitcoin'>  Bitcoin</option>
							</select>
						</label>
					</div>
					<div>
 						<button  className="btns" onClick={submitHandler}> Search </button >
					</div>
				</div>
			</form>
			<div> 
			<h4 > Details</h4>
			{status &&
<p className={classes.h}> {typeof(privKey) == 'undefined' ? <span > Address Not Found <FcHighPriority/> </span> :  <span> Valid  <FcOk/> </span>} </p> }
{status  && 
				<div>
				{ <p className={classes.h1}> Account Balance: <span style={{'fontWeight': 'bold', 'fontSize' : '20px'}}> {bal} (Wei) </span></p>}
				{reveal && <button className="btn-eye" onClick={() => clickrevealHandler()}> <span> <FaEye/> </span> </button>}
				{clickreveal && <p className={classes.h2}> <span style={{'fontSize' : '14px'}}> Private Key: </span> {privKey} </p>} 
			{ clickreveal && <div className="classes.actions">
       <button className="btnc" >
          Make Default
        </button>
        </div>
 }
         </div>}

        </div>
</div>

	);


}
export default Search;
