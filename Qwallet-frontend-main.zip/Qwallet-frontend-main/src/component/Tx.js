import React from "react";
import ReactDOM from "react-dom";
import classes from ".././component/layout/TxForm.module.css";
import { useState , useRef} from "react";
import Modal2 from "./Modal2";
import Backdrop from "./Backdrop";

function Tx() {
	const inputRef= useRef({});
const [ModelisOpen, setModelIsOpen] = useState(false);
const [senderAdd, setsenderAdd] =useState('');
//this function below is for testing


function recordTX(event) {
	const dateTime = Date.now();
setModelIsOpen(true);
event.preventDefault();
setsenderAdd('From: {'+inputRef.current["sender"].value + '}, To: {'+inputRef.current["receiver"].value+ '}, Coin: {'+inputRef.current["coin"].value + '}, Amount: {'+ inputRef.current["amount"].value+'}' +'Time: {'+dateTime+'}'); 
console.log(senderAdd);
const data =  {senderAdd } ;
	const options = 
	{
	method: 'POST',
	headers : {
		'Content-Type' : 'application/json'},
		body : JSON.stringify(data)
			};

	fetch("http://localhost:4000/record", options).then((res) => {
			return res.json();
		}).then((data) => {
		console.log (data);})

	};
//untill this line

function sendHandler(event) {
 event.preventDefault();
    setModelIsOpen(true);
  }
    function closeModalHandler() {
    setModelIsOpen(false);
  }

	return (
		<div className={classes.card2}>
			<form className={classes.form}>
				<div className={classes.control}>
					<input

        type="text"
        id="sender"
        name="sender"
        ref={el => inputRef.current["sender"] =el} 
        placeholder="sender" />
        <input
        
        type="text"
        id="receiver"
        name="receiver" 
        ref={el => inputRef.current["receiver"] =el} 
        placeholder="receiver" />
 		
 		<input
        type="text"
        id="amount"
        name="amount"
        ref={el => inputRef.current["amount"] =el} 
        placeholder="amount" />
        
        <input
        type="text"
        id="coin"
        name="coin" 
        ref={el => inputRef.current["coin"] =el} 
        placeholder="coin" />

					<div className={classes.action}>
					<span> </span>
					<button className="btns" onClick={recordTX}> Send  </button>
					
					</div>
				</div>
			</form>

{ModelisOpen && (
        <Modal2  onCancel={closeModalHandler} />
      )}
      {ModelisOpen && <Backdrop onCancel={closeModalHandler} />}
    </div>
	);
}

export default Tx;
