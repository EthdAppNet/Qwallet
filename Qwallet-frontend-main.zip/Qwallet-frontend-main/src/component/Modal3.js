import React from "react";
import ReactDOM from "react-dom";
import {useState, useRef} from 'react';
import classes from "./layout/TxForm.module.css";

function Modal3({setModelIsOpen})
{
  const [message, setMessage] = useState('');
 	const inputRef = useRef(null);

  function handleChange(props, event){
  	setModelIsOpen(false);
  	 event.preventDefault();
setMessage(inputRef.current.value);
if (inputRef.current.value=='admin'){
console.log(message)}
else{
	console.log('wrong');
}
props.onCancel();

  }
  return (
    		<div className={classes.card2}>
			<form className={classes.form}>
				<div className={classes.control}>
        	<input
       	ref={inputRef}
        type="text"
        id="message"
        name="message" 
        placeholder="munim" />
					<div className={classes.action}>
					<span> </span>
					<button className="btns" onClick={handleChange}> Login  </button>
					
					</div>
				</div>
			</form>
			</div>
)
};
export default Modal3;