import React from "react";
import ReactDOM from "react-dom";
import classes from ".././component/layout/TxForm.module.css";
import { useState,inputRef } from "react";
import Modal2 from "./Modal2";
import Backdrop from "./Backdrop";

function Login() {
const [ModelisOpen, setModelIsOpen] = useState(false);

function sendHandler() {

    setModelIsOpen(true);
  }
    function closeModalHandler() {
    setModelIsOpen(false);
  }
	return (
		<div className={classes.card2}>
			<form className={classes.form}>
				<div className={classes.control}>
				<h1> Sign in</h1>
					<input
       	ref={inputRef}
        type="text"
        id="message"
        name="message" 
        placeholder="munim" />
					<label htmlFor="rcvAddr"> Password</label>
					<input type="text" required id="rcvAddr" />
					<div className={classes.action}>
					<span> </span>
					<button className="btns" onClick={sendHandler}> login  </button>
					
					</div>
				</div>
			</form>
    </div>
	);
}

export default Login;
