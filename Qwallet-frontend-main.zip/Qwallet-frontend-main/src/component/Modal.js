import React from "react";
import ReactDOM from "react-dom";
import {useEffect, useState } from "react";
import { CopyToClipboard } from 'react-copy-to-clipboard';
import { FaCopy , FaWindowClose} from 'react-icons/fa';
import { FcApproval} from "react-icons/fc";
import classes from ".././component/layout/TxForm.module.css";
var data1;
function Modal(props) {

const [copied, setCopied] = useState(false);
const [cdata, setData] = useState("");

	function cancelHandler() {
		props.onCancel();
	}
	function copyHandler() {
			setCopied(true);
	}
	 useEffect(() => {
	fetch("http://localhost:4000/")
		.then((res) => {
			return res.json();
		})
		.then((data) => {
			//data1 = data.address;
			setData(data.address);
		}); 
 },[]);
	return (
		
		<div className="modal">

<div>	
<div className="rowC">
<p className={classes.h3}> {props.onCoin + ":" + cdata}	</p>
		<CopyToClipboard text = {cdata}>
			<button className="btn-copy" onClick={copyHandler}> <FaCopy/>
			</button>
			</CopyToClipboard>
			</div>
			<div>
  {copied ? <span  className={classes.h4}>Copied<FcApproval size='15'/> </span> : null} </div>
</div>
				<div>
			<button className="btn-close" onClick={cancelHandler}>
				<FaWindowClose />
			</button>
</div>
		</div>
	);
}
export default Modal;
