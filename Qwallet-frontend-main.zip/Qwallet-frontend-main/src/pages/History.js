import React from "react";
import ReactDOM from "react-dom";
import {useEffect , useState, useRef} from "react";
import classes from ".././component/layout/TxForm.module.css";


function History() {
	const [Hist, setHist] =useState();
	var x; 
 useEffect(() => {
	fetch("http://localhost:4000/txrecord")
		.then((res) => {
			return res.text();
			x = x+1;
		})
		.then((data) => {
			console.log(data);
			setHist(data);
		}); 
},[]);
	return (
		<div className={classes.card2} >

	<h1> Transaction History</h1>
<p> {Hist} </p>

	</div>
);
}
export default History;
