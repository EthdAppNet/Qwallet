import React from "react";
import ReactDOM from "react-dom";
import Wallet from ".././component/Wallet.js";
import classes from ".././component/layout/MainNavigation.module.css";
import Tx from ".././component/Tx.js";

function NewWalletPage() {
	return (
		<div>
			<div className="rowC">
				<Wallet text="Ethereum" />
				<span></span>
				<Wallet text="Other Coin" />
			</div>

			<div>
				<Tx />
			</div>
		</div>
	);
}

export default NewWalletPage;
