import React from "react";
import ReactDOM from "react-dom";
import Search from ".././component/Search.js";

function AddressesPage() {
    return (
        <div>
            <Search />
        </div>
    );
}
export default AddressesPage;

