import React from "react";
import {useState, useRef} from "react";
import ReactDOM from "react-dom";
import { Route, Routes } from "react-router-dom";
import History from "./pages/History";
import AddressesPage from "./pages/Addresses";
import NewWalletPage from "./pages/NewWallet";
import classes from "./component/layout/TxForm.module.css";
import MainNavigation from "./component/layout/MainNavigation";
import Wallet from "./component/Wallet";


import Backdrop from "./component/Backdrop";



function App(event)
 {

const inputRef= useRef({});

const [LoginDone, setLoginDone] = useState(false);
const [Pass, setPass] = useState();

function loginHandler(event) {
  console.log(inputRef.current["username"].value);
  console.log(inputRef.current["password"].value);
  event.preventDefault();

  if ((inputRef.current["username"].value=="admin") && (inputRef.current["password"].value=="admin" )) {
  setLoginDone(true);

  }
  else  {
  setLoginDone(false);
  setPass('Invalid login and password');
  }

}
 if (LoginDone==true)
 {
  return (
    <div>
      <MainNavigation />
      <Routes>

        <Route path="/" element={<NewWalletPage />} />
        <Route path="/favorites" element={<AddressesPage />} />
        <Route path="/All" element={<History />} />
      </Routes>
    </div>
  );
}
  else {
    return (

    <div className={classes.card2}>
      <form className={classes.form}>
        <div className={classes.control}>
        <p style={{ color: 'red' }}> {Pass} </p>
        <h2> Enter your Username and Password</h2>
        <input
        ref={el => inputRef.current["username"] =el}
        type="text"
        id="username"
        name="username" 
        placeholder="Username" />
        <input
        ref={el => inputRef.current["password"] =el}
        type="password"
        id="password"
        name="password" 
        placeholder="Password" />

          <div className={classes.action}>
      <span> </span>
          <button className="btns" onClick={loginHandler}> login  </button>
          
          </div>
        </div>
      </form>
    </div>
    );
    }
}
export default App;
